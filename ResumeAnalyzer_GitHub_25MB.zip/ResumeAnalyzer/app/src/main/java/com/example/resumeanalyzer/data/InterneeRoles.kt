package com.example.resumeanalyzer.data

data class JobRoleProfile(
    val title: String,
    val description: String,
    val requiredSkills: List<String>
)

object InterneeRoles {
    val roles = listOf(
        JobRoleProfile(
            title = "Android App Development",
            description = "Develop modern Android applications using Kotlin, Jetpack Compose, and Firebase.",
            requiredSkills = listOf(
                "Kotlin", "Java", "Android SDK", "Jetpack Compose",
                "Firebase", "REST API", "Git", "MVVM", "Room", "Coroutines"
            )
        ),
        JobRoleProfile(
            title = "Frontend Web Development",
            description = "Build responsive web interfaces using HTML, CSS, JavaScript, and React.",
            requiredSkills = listOf(
                "HTML5", "CSS3", "JavaScript", "React", "TypeScript",
                "Tailwind CSS", "Git", "REST API", "Responsive Design"
            )
        ),
        JobRoleProfile(
            title = "Full Stack Web Development",
            description = "Develop end-to-end web apps with Node.js, React, and MongoDB/SQL databases.",
            requiredSkills = listOf(
                "JavaScript", "Node.js", "Express", "React", "MongoDB",
                "SQL", "REST API", "Git", "Authentication", "TypeScript"
            )
        ),
        JobRoleProfile(
            title = "Python & Data Science",
            description = "Analyze data, train machine learning models, and build data pipelines.",
            requiredSkills = listOf(
                "Python", "Pandas", "NumPy", "Scikit-Learn", "Data Analysis",
                "Machine Learning", "SQL", "Jupyter", "Matplotlib", "Git"
            )
        ),
        JobRoleProfile(
            title = "UI/UX Design & Research",
            description = "Design user-centered mobile & web interfaces, wireframes, and interactive prototypes.",
            requiredSkills = listOf(
                "Figma", "Adobe XD", "Wireframing", "Prototyping",
                "User Research", "UI Design", "UX Design", "Design Systems", "Usability Testing"
            )
        ),
        JobRoleProfile(
            title = "Product Management Internee",
            description = "Define product vision, user stories, roadmaps, and agile sprint workflows.",
            requiredSkills = listOf(
                "Product Strategy", "Agile", "Scrum", "User Stories",
                "Market Research", "Problem Solving", "Jira", "Analytics", "Communication"
            )
        ),
        JobRoleProfile(
            title = "AI & Machine Learning Internee",
            description = "Implement NLP, Computer Vision, and Generative AI models using PyTorch & TensorFlow.",
            requiredSkills = listOf(
                "Python", "TensorFlow", "PyTorch", "NLP", "Deep Learning",
                "Computer Vision", "Scikit-Learn", "Model Deployment", "Git"
            )
        ),
        JobRoleProfile(
            title = "Cloud Computing & DevOps",
            description = "Manage cloud infrastructure, CI/CD pipelines, Docker containers, and AWS.",
            requiredSkills = listOf(
                "AWS", "Docker", "Kubernetes", "Linux", "CI/CD",
                "Git", "Shell Scripting", "Cloud Architecture", "Networking"
            )
        )
    )

    fun getRoleTitles(): List<String> = roles.map { it.title }

    fun getSkillsForRole(title: String): List<String> {
        return roles.find { it.title.equals(title, ignoreCase = true) }?.requiredSkills
            ?: emptyList()
    }
}
