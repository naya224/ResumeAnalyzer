package com.example.resumeanalyzer.model

enum class CandidateStatus {
    PENDING,
    SHORTLISTED,
    REJECTED
}

data class Candidate(
    val id: String = "",
    val name: String = "",
    val email: String = "",
    val phone: String = "",
    val appliedRole: String = "",
    val resumeFileName: String = "",
    val extractedText: String = "",
    val jobFitPercentage: Int = 0,
    val sentimentScore: Int = 0,
    val overallScore: Int = 0,
    val matchedSkills: List<String> = emptyList(),
    val missingSkills: List<String> = emptyList(),
    val sentimentLabel: String = "",
    val positiveWords: List<String> = emptyList(),
    val negativeWords: List<String> = emptyList(),
    val status: CandidateStatus = CandidateStatus.PENDING,
    val timestamp: Long = System.currentTimeMillis(),
)
