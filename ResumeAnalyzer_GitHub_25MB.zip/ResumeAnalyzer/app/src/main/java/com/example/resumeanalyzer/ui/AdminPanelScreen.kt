package com.example.resumeanalyzer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.resumeanalyzer.data.CandidateRepository
import com.example.resumeanalyzer.data.InterneeRoles
import com.example.resumeanalyzer.model.Candidate
import com.example.resumeanalyzer.model.CandidateStatus

private val Navy = Color(0xFF263B80)
private val LightBackground = Color(0xFFF3F5FA)
private val GreenSuccess = Color(0xFF16834A)
private val RedDanger = Color(0xFFCA4545)
private val OrangeWarning = Color(0xFFD97706)

@Composable
fun AdminPanelScreen() {
    val candidates by CandidateRepository.candidates.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedRoleFilter by remember { mutableStateOf("All Roles") }
    var selectedStatusFilter by remember { mutableStateOf("ALL") }

    var selectedCandidateForDetail by remember { mutableStateOf<Candidate?>(null) }

    val totalCount = candidates.size
    val shortlistedCount = candidates.count { it.status == CandidateStatus.SHORTLISTED }
    val pendingCount = candidates.count { it.status == CandidateStatus.PENDING }
    val avgFit = if (candidates.isNotEmpty()) {
        candidates.map { it.jobFitPercentage }.average().toInt()
    } else 0

    val roleFilterOptions = listOf("All Roles") + InterneeRoles.getRoleTitles()

    val filteredCandidates = candidates.filter { candidate ->
        val matchesQuery = searchQuery.isBlank() ||
                candidate.name.contains(searchQuery, ignoreCase = true) ||
                candidate.email.contains(searchQuery, ignoreCase = true) ||
                candidate.appliedRole.contains(searchQuery, ignoreCase = true) ||
                candidate.matchedSkills.any { it.contains(searchQuery, ignoreCase = true) }

        val matchesRole = (selectedRoleFilter == "All Roles") ||
                candidate.appliedRole.equals(selectedRoleFilter, ignoreCase = true)

        val matchesStatus = when (selectedStatusFilter) {
            "SHORTLISTED" -> candidate.status == CandidateStatus.SHORTLISTED
            "REJECTED" -> candidate.status == CandidateStatus.REJECTED
            "PENDING" -> candidate.status == CandidateStatus.PENDING
            else -> true
        }

        matchesQuery && matchesRole && matchesStatus
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LightBackground)
            .padding(16.dp),
    ) {
        Text(
            text = "Internee.pk Admin Dashboard",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Navy
        )
        Text(
            text = "Candidate Screening, Review & Shortlisting Panel",
            fontSize = 13.sp,
            color = Color.DarkGray
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricCard("Total", totalCount.toString(), Navy, Modifier.weight(1f))
            MetricCard("Shortlisted", shortlistedCount.toString(), GreenSuccess, Modifier.weight(1f))
            MetricCard("Pending", pendingCount.toString(), OrangeWarning, Modifier.weight(1f))
            MetricCard("Avg Fit", "$avgFit%", Navy, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search candidates, emails, or skills...") },
            singleLine = true,
            colors = TextFieldDefaults.colors(
                unfocusedContainerColor = Color.White,
                focusedContainerColor = Color.White
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(roleFilterOptions) { role ->
                FilterChip(
                    selected = selectedRoleFilter == role,
                    onClick = { selectedRoleFilter = role },
                    label = { Text(role, fontSize = 12.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val statusOptions = listOf("ALL", "PENDING", "SHORTLISTED", "REJECTED")
            statusOptions.forEach { status ->
                FilterChip(
                    selected = selectedStatusFilter == status,
                    onClick = { selectedStatusFilter = status },
                    label = { Text(status, fontSize = 11.sp) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (filteredCandidates.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (candidates.isEmpty()) "No candidate submissions yet."
                    else "No candidates match the current filters.",
                    color = Color.Gray
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredCandidates, key = { it.id }) { candidate ->
                    CandidateCard(
                        candidate = candidate,
                        onShortlist = {
                            CandidateRepository.updateCandidateStatus(candidate.id, CandidateStatus.SHORTLISTED)
                        },
                        onReject = {
                            CandidateRepository.updateCandidateStatus(candidate.id, CandidateStatus.REJECTED)
                        },
                        onClickDetail = {
                            selectedCandidateForDetail = candidate
                        }
                    )
                }
            }
        }
    }

    selectedCandidateForDetail?.let { candidate ->
        AlertDialog(
            onDismissRequest = { selectedCandidateForDetail = null },
            confirmButton = {
                TextButton(onClick = { selectedCandidateForDetail = null }) {
                    Text("Close")
                }
            },
            title = {
                Text(
                    text = candidate.name.ifEmpty { "Candidate Detail" },
                    fontWeight = FontWeight.Bold,
                    color = Navy
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(vertical = 8.dp)
                ) {
                    Text("Email: ${candidate.email}")
                    Text("Phone: ${candidate.phone}")
                    Text("Applied Role: ${candidate.appliedRole}")
                    Text("Resume File: ${candidate.resumeFileName}")

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Job Fit Match: ${candidate.jobFitPercentage}%", fontWeight = FontWeight.Bold, color = Navy)
                    Text("Sentiment Score: ${candidate.sentimentScore}% (${candidate.sentimentLabel})")

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Matched Skills (${candidate.matchedSkills.size}):", fontWeight = FontWeight.Bold, color = GreenSuccess)
                    candidate.matchedSkills.forEach { Text("✓ $it") }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("Missing Skills (${candidate.missingSkills.size}):", fontWeight = FontWeight.Bold, color = RedDanger)
                    candidate.missingSkills.forEach { Text("• $it") }

                    if (candidate.extractedText.isNotBlank()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Extracted Resume Text:", fontWeight = FontWeight.Bold)
                        Text(
                            text = candidate.extractedText,
                            fontSize = 11.sp,
                            color = Color.DarkGray,
                            modifier = Modifier
                                .background(Color(0xFFEFEFEF), RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Button(
                            onClick = {
                                CandidateRepository.updateCandidateStatus(candidate.id, CandidateStatus.SHORTLISTED)
                                selectedCandidateForDetail = candidate.copy(status = CandidateStatus.SHORTLISTED)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GreenSuccess)
                        ) {
                            Text("Shortlist")
                        }

                        Button(
                            onClick = {
                                CandidateRepository.updateCandidateStatus(candidate.id, CandidateStatus.REJECTED)
                                selectedCandidateForDetail = candidate.copy(status = CandidateStatus.REJECTED)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RedDanger)
                        ) {
                            Text("Reject")
                        }
                    }
                }
            }
        )
    }
}

@Composable
fun MetricCard(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = color)
            Text(title, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
fun CandidateCard(
    candidate: Candidate,
    onShortlist: () -> Unit,
    onReject: () -> Unit,
    onClickDetail: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClickDetail),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = candidate.name.ifEmpty { "Anonymous Applicant" },
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Navy
                    )
                    Text(
                        text = candidate.appliedRole,
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )
                }

                StatusBadge(candidate.status)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Match Fit: ${candidate.jobFitPercentage}%",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Navy
                )

                Text(
                    text = "Sentiment: ${candidate.sentimentScore}%",
                    fontSize = 12.sp,
                    color = Color.DarkGray
                )
            }

            LinearProgressIndicator(
                progress = { candidate.jobFitPercentage / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                color = Navy
            )

            if (candidate.email.isNotEmpty()) {
                Text("Email: ${candidate.email}", fontSize = 11.sp, color = Color.Gray)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onReject,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = RedDanger),
                    modifier = Modifier.padding(end = 8.dp)
                ) {
                    Text("Reject", fontSize = 12.sp)
                }

                Button(
                    onClick = onShortlist,
                    colors = ButtonDefaults.buttonColors(containerColor = GreenSuccess)
                ) {
                    Text("Shortlist", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: CandidateStatus) {
    val (bgColor, textColor, text) = when (status) {
        CandidateStatus.SHORTLISTED -> Triple(Color(0xFFE6F4EA), GreenSuccess, "Shortlisted")
        CandidateStatus.REJECTED -> Triple(Color(0xFFFCE8E6), RedDanger, "Rejected")
        CandidateStatus.PENDING -> Triple(Color(0xFFFEF3C7), OrangeWarning, "Pending")
    }

    Box(
        modifier = Modifier
            .background(bgColor, RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
