package com.example.resumeanalyzer

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.resumeanalyzer.data.CandidateRepository
import com.example.resumeanalyzer.data.InterneeRoles
import com.example.resumeanalyzer.model.Candidate
import com.example.resumeanalyzer.ui.AdminPanelScreen
import com.example.resumeanalyzer.ui.theme.ResumeAnalyzerTheme
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.util.concurrent.Executors

private val Navy = Color(0xFF263B80)
private val LightBackground = Color(0xFFF3F5FA)

data class ResumeAnalysis(
    val percentage: Int,
    val matchedSkills: List<String>,
    val missingSkills: List<String>,
)

data class SentimentResult(
    val percentage: Int,
    val label: String,
    val positiveWords: List<String>,
    val negativeWords: List<String>,
)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        PDFBoxResourceLoader.init(applicationContext)

        setContent {
            ResumeAnalyzerTheme {
                MainAppContainer()
            }
        }
    }
}

@Composable
fun MainAppContainer() {
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Navy,
            contentColor = Color.White
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Candidate Apply", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Admin Panel", fontWeight = FontWeight.Bold) }
            )
        }

        when (selectedTab) {
            0 -> ResumeAnalyzerScreen()
            1 -> AdminPanelScreen()
        }
    }
}

@Composable
fun ResumeAnalyzerScreen() {

    var candidateName by remember { mutableStateOf("") }
    var candidateEmail by remember { mutableStateOf("") }
    var candidatePhone by remember { mutableStateOf("") }

    var selectedFileName by remember { mutableStateOf("") }
    var resumeText by remember { mutableStateOf("") }

    val roles = InterneeRoles.getRoleTitles()
    var selectedRole by remember { mutableStateOf(roles.firstOrNull() ?: "Android App Development") }

    var analysis by remember { mutableStateOf<ResumeAnalysis?>(null) }
    var sentiment by remember { mutableStateOf<SentimentResult?>(null) }
    var errorMessage by remember { mutableStateOf("") }
    var successMessage by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var dropdownExpanded by remember { mutableStateOf(false) }

    val executor = remember { Executors.newSingleThreadExecutor() }
    val context = androidx.compose.ui.platform.LocalContext.current

    val resumePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->

        if (uri != null) {

            isLoading = true
            errorMessage = ""
            successMessage = ""
            analysis = null
            sentiment = null

            selectedFileName = getFileNameFromUri(context, uri)

            executor.execute {
                try {
                    val extractedText = context.contentResolver
                        .openInputStream(uri)?.use { input ->

                            if (selectedFileName.lowercase().endsWith(".pdf")) {
                                PDDocument.load(input).use { document ->
                                    PDFTextStripper().getText(document)
                                }
                            } else {
                                input.bufferedReader().use { it.readText() }
                            }

                        } ?: throw Exception("File could not be opened")

                    (context as? ComponentActivity)?.runOnUiThread {
                        resumeText = extractedText
                        isLoading = false
                    }

                } catch (e: Exception) {
                    (context as? ComponentActivity)?.runOnUiThread {
                        errorMessage = e.message ?: "Unable to read file"
                        isLoading = false
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LightBackground)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {

        Text(
            text = "Internee.pk AI Resume Portal",
            style = MaterialTheme.typography.headlineMedium,
            color = Navy,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = "Submit your resume and get instant AI screening & job match analysis.",
            color = Color.DarkGray,
            fontSize = 13.sp
        )

        // Candidate Personal Info Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Candidate Details",
                    style = MaterialTheme.typography.titleMedium,
                    color = Navy,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = candidateName,
                    onValueChange = { candidateName = it },
                    label = { Text("Full Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = candidateEmail,
                    onValueChange = { candidateEmail = it },
                    label = { Text("Email Address") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = candidatePhone,
                    onValueChange = { candidatePhone = it },
                    label = { Text("Phone Number") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // File Selection Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Upload Resume (PDF / TXT)",
                    style = MaterialTheme.typography.titleMedium,
                    color = Navy,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        resumePicker.launch(
                            arrayOf("application/pdf", "text/plain")
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Navy)
                ) {
                    Text("Select Resume File")
                }

                if (selectedFileName.isNotEmpty()) {
                    Text(
                        text = "Selected: $selectedFileName",
                        color = Color.DarkGray,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }

        if (isLoading) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CircularProgressIndicator(color = Navy)
                Text("Extracting resume text...", color = Navy)
            }
        }

        if (errorMessage.isNotEmpty()) {
            Text(
                text = errorMessage,
                color = MaterialTheme.colorScheme.error,
                fontWeight = FontWeight.Bold
            )
        }

        if (successMessage.isNotEmpty()) {
            Text(
                text = successMessage,
                color = Color(0xFF16834A),
                fontWeight = FontWeight.Bold
            )
        }

        // Job Role Selection Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Select Internee.pk Internship Role",
                    style = MaterialTheme.typography.titleMedium,
                    color = Navy,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Box {
                    OutlinedButton(
                        onClick = { dropdownExpanded = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(selectedRole, modifier = Modifier.weight(1f))
                        Text("▼")
                    }

                    DropdownMenu(
                        expanded = dropdownExpanded,
                        onDismissRequest = { dropdownExpanded = false }
                    ) {
                        roles.forEach { role ->
                            DropdownMenuItem(
                                text = { Text(role) },
                                onClick = {
                                    selectedRole = role
                                    dropdownExpanded = false
                                    analysis = null
                                }
                            )
                        }
                    }
                }
            }
        }

        Button(
            onClick = {
                if (resumeText.isBlank()) {
                    errorMessage = "Please upload a resume first."
                } else {
                    val analysisRes = analyzeResume(resumeText, selectedRole)
                    val sentimentRes = analyzeSentiment(resumeText)

                    analysis = analysisRes
                    sentiment = sentimentRes
                    errorMessage = ""

                    // Save Candidate to Repository / Firebase
                    val overallScore = (analysisRes.percentage + sentimentRes.percentage) / 2
                    val candidate = Candidate(
                        name = candidateName.ifBlank { "Applicant" },
                        email = candidateEmail,
                        phone = candidatePhone,
                        appliedRole = selectedRole,
                        resumeFileName = selectedFileName,
                        extractedText = resumeText,
                        jobFitPercentage = analysisRes.percentage,
                        sentimentScore = sentimentRes.percentage,
                        overallScore = overallScore,
                        matchedSkills = analysisRes.matchedSkills,
                        missingSkills = analysisRes.missingSkills,
                        sentimentLabel = sentimentRes.label,
                        positiveWords = sentimentRes.positiveWords,
                        negativeWords = sentimentRes.negativeWords
                    )

                    CandidateRepository.addCandidate(candidate)
                    successMessage = "Application & Resume Analysis submitted successfully!"
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            enabled = resumeText.isNotBlank() && !isLoading,
            colors = ButtonDefaults.buttonColors(containerColor = Navy)
        ) {
            Text("Analyze & Submit Application", fontSize = 16.sp)
        }

        analysis?.let { (percentage, matchedSkills, missingSkills) ->

            HorizontalDivider()

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Resume Analysis Report",
                        style = MaterialTheme.typography.titleLarge,
                        color = Navy,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text("Target Role: $selectedRole")

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Job Fit Match: $percentage%",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Navy,
                        fontWeight = FontWeight.Bold
                    )

                    LinearProgressIndicator(
                        progress = { percentage / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        color = Navy
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Matched Skills (${matchedSkills.size})",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color(0xFF16834A),
                        fontWeight = FontWeight.Bold
                    )

                    if (matchedSkills.isEmpty()) {
                        Text("No matching skills found.")
                    } else {
                        matchedSkills.forEach {
                            Text("✓ $it")
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Missing Skills (${missingSkills.size})",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color(0xFFCA4545),
                        fontWeight = FontWeight.Bold
                    )

                    if (missingSkills.isEmpty()) {
                        Text("No missing skills.")
                    } else {
                        missingSkills.forEach {
                            Text("• $it")
                        }
                    }
                }
            }
        }

        sentiment?.let { (percentage, label, positiveWords, negativeWords) ->

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Resume Sentiment & Tone Analysis",
                        style = MaterialTheme.typography.titleLarge,
                        color = Navy,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("Sentiment Score: $percentage%")
                    Text("Tone Assessment: $label")

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("Positive Identifiers: ${if (positiveWords.isEmpty()) "None" else positiveWords.joinToString()}")
                    Text("Areas for Improvement: ${if (negativeWords.isEmpty()) "None" else negativeWords.joinToString()}")
                }
            }
        }

        if (resumeText.isNotBlank()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Extracted Resume Text Preview",
                        style = MaterialTheme.typography.titleMedium,
                        color = Navy,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = resumeText,
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )
                }
            }
        }
    }
}

fun getFileNameFromUri(
    context: android.content.Context,
    uri: Uri
): String {

    var name = "resume.txt"

    context.contentResolver.query(
        uri,
        null,
        null,
        null,
        null
    )?.use { cursor ->

        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)

        if (cursor.moveToFirst() && nameIndex >= 0) {
            name = cursor.getString(nameIndex)
        }
    }

    return name
}

fun analyzeResume(text: String, role: String): ResumeAnalysis {

    val requiredSkills = InterneeRoles.getSkillsForRole(role)
    val resumeText = text.lowercase()

    val matched = requiredSkills.filter { skill ->
        Regex(
            "(?<![a-z0-9])" +
                    Regex.escape(skill.lowercase()) +
                    "(?![a-z0-9])"
        ).containsMatchIn(resumeText)
    }

    val missing = requiredSkills - matched.toSet()

    val percentage = if (requiredSkills.isNotEmpty()) {
        (matched.size * 100) / requiredSkills.size
    } else {
        0
    }

    return ResumeAnalysis(
        percentage = percentage,
        matchedSkills = matched,
        missingSkills = missing
    )
}

fun analyzeSentiment(text: String): SentimentResult {

    val positiveDictionary = listOf(
        "excellent", "good", "successful",
        "achievement", "teamwork", "creative",
        "skilled", "experienced", "strong",
        "improved", "developed", "completed",
        "leadership", "managed", "built", "designed"
    )

    val negativeDictionary = listOf(
        "poor", "weak", "failed",
        "inexperienced", "unable", "bad",
        "limited", "problem", "difficult"
    )

    val words = Regex("[a-z]+")
        .findAll(text.lowercase())
        .map { it.value }
        .toList()

    val positive = positiveDictionary.filter { it in words }
    val negative = negativeDictionary.filter { it in words }

    val total = positive.size + negative.size

    val score = if (total > 0) {
        (positive.size * 100) / total
    } else {
        50
    }

    val label = when {
        total == 0 -> "Neutral / Objective"
        score >= 60 -> "Strong & Professional Tone"
        score <= 40 -> "Needs Improvement"
        else -> "Balanced Tone"
    }

    return SentimentResult(
        percentage = score,
        label = label,
        positiveWords = positive,
        negativeWords = negative
    )
}
