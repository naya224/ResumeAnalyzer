package com.example.resumeanalyzer.data

import com.example.resumeanalyzer.model.Candidate
import com.example.resumeanalyzer.model.CandidateStatus
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID

object CandidateRepository {

    private val _candidates = MutableStateFlow<List<Candidate>>(emptyList())
    val candidates: StateFlow<List<Candidate>> = _candidates

    private var firestore: FirebaseFirestore? = try {
        FirebaseFirestore.getInstance()
    } catch (e: Exception) {
        null
    }

    init {
        listenToFirebaseUpdates()
    }

    private fun listenToFirebaseUpdates() {
        try {
            firestore?.collection("candidates")
                ?.addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener

                    val list = mutableListOf<Candidate>()
                    for (doc in snapshot.documents) {
                        try {
                            val id = doc.id
                            val name = doc.getString("name") ?: ""
                            val email = doc.getString("email") ?: ""
                            val phone = doc.getString("phone") ?: ""
                            val appliedRole = doc.getString("appliedRole") ?: ""
                            val resumeFileName = doc.getString("resumeFileName") ?: ""
                            val extractedText = doc.getString("extractedText") ?: ""
                            val jobFitPercentage = doc.getLong("jobFitPercentage")?.toInt() ?: 0
                            val sentimentScore = doc.getLong("sentimentScore")?.toInt() ?: 0
                            val overallScore = doc.getLong("overallScore")?.toInt() ?: 0
                            val sentimentLabel = doc.getString("sentimentLabel") ?: ""

                            @Suppress("UNCHECKED_CAST")
                            val matchedSkills = doc.get("matchedSkills") as? List<String> ?: emptyList()
                            @Suppress("UNCHECKED_CAST")
                            val missingSkills = doc.get("missingSkills") as? List<String> ?: emptyList()
                            @Suppress("UNCHECKED_CAST")
                            val positiveWords = doc.get("positiveWords") as? List<String> ?: emptyList()
                            @Suppress("UNCHECKED_CAST")
                            val negativeWords = doc.get("negativeWords") as? List<String> ?: emptyList()

                            val statusStr = doc.getString("status") ?: CandidateStatus.PENDING.name
                            val status = try {
                                CandidateStatus.valueOf(statusStr)
                            } catch (e: Exception) {
                                CandidateStatus.PENDING
                            }

                            val timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()

                            list.add(
                                Candidate(
                                    id = id,
                                    name = name,
                                    email = email,
                                    phone = phone,
                                    appliedRole = appliedRole,
                                    resumeFileName = resumeFileName,
                                    extractedText = extractedText,
                                    jobFitPercentage = jobFitPercentage,
                                    sentimentScore = sentimentScore,
                                    overallScore = overallScore,
                                    matchedSkills = matchedSkills,
                                    missingSkills = missingSkills,
                                    sentimentLabel = sentimentLabel,
                                    positiveWords = positiveWords,
                                    negativeWords = negativeWords,
                                    status = status,
                                    timestamp = timestamp
                                )
                            )
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }

                    if (list.isNotEmpty()) {
                        _candidates.value = list.sortedByDescending { it.timestamp }
                    }
                }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun addCandidate(candidate: Candidate) {
        val id = candidate.id.ifEmpty { UUID.randomUUID().toString() }
        val newCandidate = candidate.copy(id = id)

        val currentList = _candidates.value.toMutableList()
        currentList.removeAll { it.id == id }
        currentList.add(0, newCandidate)
        _candidates.value = currentList

        try {
            val data = hashMapOf(
                "name" to newCandidate.name,
                "email" to newCandidate.email,
                "phone" to newCandidate.phone,
                "appliedRole" to newCandidate.appliedRole,
                "resumeFileName" to newCandidate.resumeFileName,
                "extractedText" to newCandidate.extractedText,
                "jobFitPercentage" to newCandidate.jobFitPercentage,
                "sentimentScore" to newCandidate.sentimentScore,
                "overallScore" to newCandidate.overallScore,
                "matchedSkills" to newCandidate.matchedSkills,
                "missingSkills" to newCandidate.missingSkills,
                "sentimentLabel" to newCandidate.sentimentLabel,
                "positiveWords" to newCandidate.positiveWords,
                "negativeWords" to newCandidate.negativeWords,
                "status" to newCandidate.status.name,
                "timestamp" to newCandidate.timestamp
            )

            firestore?.collection("candidates")
                ?.document(id)
                ?.set(data)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun updateCandidateStatus(candidateId: String, status: CandidateStatus) {
        val currentList = _candidates.value.map {
            if (it.id == candidateId) it.copy(status = status) else it
        }
        _candidates.value = currentList

        try {
            firestore?.collection("candidates")
                ?.document(candidateId)
                ?.update("status", status.name)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
